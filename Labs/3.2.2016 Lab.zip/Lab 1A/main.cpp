/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on March 2, 2016, 7:47 AM
 */

#include <cstdlib>
#include <iostream>
using namespace std;
/*
 * 
 */
int main(int argc, char** argv) {
    float nasa, militar, total, pernasa, permili;
        total   = 3.8e12f; // total federal budget
        nasa    = 1.74e10f; // nasa budget
        militar = 6.1e11f; // military budget
       
        pernasa = (nasa / total) * 100;
        cout << pernasa<< endl;
        
        permili = (militar/total)* 100;
        cout << permili;
    
    return 0;
}

