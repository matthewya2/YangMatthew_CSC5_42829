/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on March 2, 2016, 10:38 AM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    
    // define variables
    float google, usa, ireland, goousa, gootusa, gooire, gootire;
    
    //define values of variables
    google = 74.54e9f;  // what google makes in a year
    usa = .40;          // what google will have to pay in taxes in the USA
    ireland = .125;     // what google will have to pay in taxes in Ireland
    
            goousa = google*usa;
            gootusa = google - goousa;
    cout << "google will make " <<gootusa << " in the USA"<<endl;
    gooire = google * ireland;
    gootire= google - gooire;
    cout << "google will make " << gootire<< " in Ireland";
    return 0;
}

