/* 
 * File:   main.cpp
 * Author: rcc
 *
 * Created on March 23, 2016, 10:44 AM
 */

#include <cstdlib>
#include <iostream>
using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
float gradeN;     //number grade
    
    
    cout << "what is your grade?";
    cin  >> gradeN;
    
    //get the letter grade from the number grade
    (gradeN <60)? cout<< "F": ;
    
    //couldn't finish
    return 0;
}

